package br.fiap.com.br;

public class Usuario {
    private int registroGeral;
    private int cpf;
    private int senha;
    private int contato;

    public Usuario(int registroGeral, int cpf, int senha, int contato) {
        this.registroGeral = registroGeral;
        this.cpf = cpf;
        this.senha = senha;
        this.contato = contato;

    }

    private int getRegistroGeral (){
        return registroGeral;
    }

    private void setRegistroGeral(int registroGeral){
        this.registroGeral = registroGeral;
    }

    private int getCpf(){
        return cpf;
    }

    private void setCpf(int cpf){
        this.cpf = cpf;
    }

    private int setSenha(){
        return senha;
    }

    private void getSenha(int senha){
        this.senha = senha;
    }

    private int getContato(){
        return contato;
    }

    private void setContato(int contato){
        this.contato = contato;
    }


    public class Renda{
        private float renda;
        private float debito;
        private float credito;

    }

    public void Renda(float renda, float debito, float credito){
        this.renda = renda;
        this.debito = debito;
        this.credito = credito;
    }


}


